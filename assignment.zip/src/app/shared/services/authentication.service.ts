import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  /**
   * Performs the auth
   * @param userName user name of user
   * @param password password of user
   */
  login(userName: string, password: string) : Observable<boolean> {
    if(userName.toLowerCase() == 'altimetrikuser' && password == 'test') {
      return of(true)
    } else {
      return of(false);
    }
  }

  /**
   * Returns the authenticated user
   */
    getAuthenticatedUser() {
    if (!localStorage.getItem('authUser')) {
      return false;
    }
    return true;
  }
}
