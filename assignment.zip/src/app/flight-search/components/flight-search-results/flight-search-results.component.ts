import { AfterViewInit, Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-flight-search-results',
  templateUrl: './flight-search-results.component.html',
  styleUrls: ['./flight-search-results.component.scss']
})
export class FlightSearchResultsComponent implements AfterViewInit {

  displayedColumns: string[] = ['flightNumber', 'airlineName', 'departureTime', 'arrivalTime', 'duration', 'stops', 'price'];
  dataSource = new MatTableDataSource<any>();
  @Input() tableData: any;

  constructor() { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('TableTwoSort') sort: MatSort;

  ngAfterViewInit() {
    this.dataSource.data = this.tableData;
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
}
