import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightSearchService } from 'src/app/shared/services/flight-search.service';

@Component({
  selector: 'app-flight-search-details',
  templateUrl: './flight-search-details.component.html',
  styleUrls: ['./flight-search-details.component.scss']
})
export class FlightSearchDetailsComponent implements OnInit {

  cities: string[] = ['Mumbai', 'Banglore', 'Indore'];
  destinationCities: string[];
  flightSearchForm: FormGroup;
  minDate: Date;
  maxDate: Date;
  flightSearchResults: any;

  constructor(private fb:FormBuilder, private httpService: FlightSearchService) {
      // Set the minimum to current date and December 31st the following year.
      const currentYear = new Date().getFullYear();
      this.minDate = new Date();
      this.maxDate = new Date(currentYear, 11, 31);
   }

  ngOnInit(): void {
    this.flightSearchForm = this.fb.group({
      sourceCity: [null, [Validators.required]],
      destinationCity: [null, [Validators.required]],
      dateOfJourney: [null, [Validators.required]],
      returnDate: [null]
    })
  }

  get f() {
    return this.flightSearchForm.controls;
  }

  getResults() {
    this.flightSearchResults = null;
    this.httpService.getFlightDetails().subscribe(data => {
      if(data) {
        this.flightSearchResults = data.filter((item:any) => {
          return (item.source == this.f.sourceCity.value && item.destination == this.f.destinationCity.value);
        });
      }
    }, err => {
      alert('Something went wrong !');
    })
  }

  resetFilters() {
    this.destinationCities = [];
    this.destinationCities = this.cities.filter(data => {
      return data !== this.f.sourceCity.value;
    })
  }
}
