import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightSearchDetailsComponent } from './flight-search-details.component';

describe('FlightSearchDetailsComponent', () => {
  let component: FlightSearchDetailsComponent;
  let fixture: ComponentFixture<FlightSearchDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FlightSearchDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightSearchDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
